# Fundamentos de Aprendizaje Automático

## Práctica 1

## Alejandro Jiménez Gutiérrez
## Diego Rodríguez Atencia

## Implementación de un sistema de clasificado